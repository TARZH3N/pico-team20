#ifndef LWIP_HTTPSERVER_NETCONN_H
#define LWIP_HTTPSERVER_NETCONN_H

void http_server_netconn_init(void);

#endif /* LWIP_HTTPSERVER_NETCONN_H */
