/*
 * Copyright (c) 2021 Sandeep Mistry
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "pico/stdlib.h"
#include "pico/multicore.h"
#include "hardware/clocks.h"
#include "lwip/dhcp.h"
#include "lwip/init.h"
#include "lwip/apps/httpd.h"
#include "rmii_ethernet/netif.h"

#include "lwip/pbuf.h"
#include <stdio.h>

void print_packet(struct pbuf* p) {
    while (p != NULL) { // Traverse through the pbuf chain
        for (u16_t i = 0; i < p->len; i++) {
            // Print each byte
            printf("%02x ", ((unsigned char*)p->payload)[i]);
            if ((i + 1) % 16 == 0) {
                // For formatting, print a newline every 16 bytes
                printf("\n");
            }
        }
        p = p->next; // Move to the next pbuf in the chain
    }
    printf("\n");
}

#include "lwip/inet_chksum.h"
#include "lwip/icmp.h"
#include "lwip/ip4.h"

void send_icmp_ping(struct netif *netif, const ip4_addr_t *dest_ip) {
    // Allocate pbuf for ICMP packet
    struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, sizeof(struct icmp_echo_hdr), PBUF_RAM);
    if (!p) {
        printf("Failed to allocate pbuf for ICMP\n");
        return;
    }

    struct icmp_echo_hdr *iecho = (struct icmp_echo_hdr *)p->payload;

    // Fill in the ICMP header
    ICMPH_TYPE_SET(iecho, ICMP_ECHO);
    ICMPH_CODE_SET(iecho, 0);
    iecho->chksum = 0;
    iecho->id = htons(0xABCD); // arbitrary ID
    iecho->seqno = htons(1);   // sequence number

    // Calculate the ICMP checksum
    iecho->chksum = inet_chksum(iecho, p->len);

    // Send the packet
    // ip4_output_if(p, NULL, dest_ip, &netif->ip_addr, IP_PROTO_ICMP);
    ip4_output_if(p, &netif->ip_addr, dest_ip, IP_DEFAULT_TTL, 0, IP_PROTO_ICMP, netif);
    //print_packet(p);
    pbuf_free(p);
    printf("sent\n");

}




#include "lwip/raw.h"
#include "lwip/icmp.h"
#include "lwip/ip.h" // for `ip_addr_t` and `ipaddr_ntoa`

// Define a basic ICMP header structure

// This will be called whenever an ICMP packet is received
static u8_t icmp_recv(void *arg, struct raw_pcb *pcb, struct pbuf *p, const ip_addr_t *addr) {
    printf("Received ICMP packet\n");

    if (p->len >= sizeof(struct icmp_hdr)) {
        struct icmp_hdr *icmphdr = (struct icmp_hdr *)p->payload;

        print_packet(p);
        printf("ICMP type: %d\n", icmphdr->type);

        // Check for ICMP Echo Reply type
        if (icmphdr->type == ICMP_ER) {
            struct icmp_echo_hdr *iecho = (struct icmp_echo_hdr *)p->payload;
            if (ntohs(iecho->id) == 0xABCD) { // Match the identifier you used
                printf("Received ICMP Echo Reply with correct ID from: %s\n", ipaddr_ntoa(addr));
            } else {
                printf("Received ICMP Echo Reply with different ID from: %s\n", ipaddr_ntoa(addr));
            }
        } else {
            printf("Received non-Echo Reply ICMP packet from: %s\n", ipaddr_ntoa(addr));
        }
    } else {
        printf("Received ICMP packet too short from: %s\n", ipaddr_ntoa(addr));
    }

    // Return 1 to indicate that the packet has been dealt with
    // and doesn't need further processing by lwIP
    return 1;
}

// Setup function to listen for ICMP packets
void setup_icmp_listener(void) {
    struct raw_pcb *raw = raw_new(IP_PROTO_ICMP);
    raw_recv(raw, icmp_recv, NULL);
    raw_bind(raw, IP_ADDR_ANY);
    printf("ICMP listener set up\n");
}



void netif_link_callback(struct netif *netif)
{
    printf("netif link status changed %s\n", netif_is_link_up(netif) ? "up" : "down");
}

void netif_status_callback(struct netif *netif)
{
    printf("netif status changed %s\n", ip4addr_ntoa(netif_ip4_addr(netif)));
}

int main() {
    
    // LWIP network interface
    struct netif netif;

    struct netif_rmii_ethernet_config netif_config = {
        pio0, // PIO:            0
        0,    // pio SM:         0 and 1
        6,    // rx pin start:   6, 7, 8    => RX0, RX1, CRS
        10,   // tx pin start:   10, 11, 12 => TX0, TX1, TX-EN
        14,   // mdio pin start: 14, 15   => ?MDIO, MDC
        NULL, // MAC address (optional - NULL generates one based on flash id) 
    };

    // change the system clock to use the RMII reference clock from pin 20
    clock_configure_gpin(clk_sys, 20, 50 * MHZ, 50 * MHZ);
    sleep_ms(100);

    // initialize stdio after the clock change
    stdio_init_all();
    sleep_ms(5000);
    
    printf("pico rmii ethernet - httpd\n");

    // initilize LWIP in NO SYS mode
    lwip_init();

    // initialize the PIO base RMII Ethernet network interface
    netif_rmii_ethernet_init(&netif, &netif_config);
    
    // assign callbacks for link and status
    netif_set_link_callback(&netif, netif_link_callback);
    netif_set_status_callback(&netif, netif_status_callback);

    // set the default interface and bring it up
    netif_set_default(&netif);
    netif_set_up(&netif);

#include "lwip/opt.h"
#include "lwip/init.h"
#include "lwip/netif.h"
#include "lwip/ip4_addr.h"
#include "lwip/tcpip.h"
#include "netif/ethernet.h"


#define MY_IP_ADDR      "192.168.1.100"
#define MY_NET_MASK     "255.255.255.0"
#define MY_GATEWAY_ADDR "192.168.1.1"

ip4_addr_t ipaddr, netmask, gw;

// Disable DHCP client if it was previously enabled on the interface
// netif_set_down(&your_netif);
// dhcp_stop(&your_netif);


IP4_ADDR(&ipaddr, 192,168,1,100);
IP4_ADDR(&netmask, 255,255,255,0);
IP4_ADDR(&gw, 192,168,1,1);

// Apply the configuration
netif_set_addr(&netif, &ipaddr , &netmask, &gw);

netif_set_up(&netif);


    // Start DHCP client and httpd
    //dhcp_start(&netif);
    httpd_init();

    //setup_icmp_listener();

    // setup core 1 to monitor the RMII ethernet interface
    // this let's core 0 do other things :)
    multicore_launch_core1(netif_rmii_ethernet_loop);

    ip4_addr_t google_dns;
    IP4_ADDR(&google_dns, 8,8,8,8); // 8.8.8.8

    while (1) {
        tight_loop_contents();
            // sleep_ms(10000);

            // send_icmp_ping(&netif, &google_dns);
    }

    return 0;
}
