# pico-team20
INF2004 IS PROJECT

## Diagrams
<a href="/Flowchart.jpg">Flow Chart</a>
<br>
<a href="/Block%20Diagram.png">Block Diagram</a>
